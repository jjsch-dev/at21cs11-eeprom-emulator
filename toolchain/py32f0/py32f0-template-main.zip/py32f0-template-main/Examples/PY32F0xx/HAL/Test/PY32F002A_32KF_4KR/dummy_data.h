#include "py32f0xx_hal.h"

#define DUMMY_DATA_SIZE 25360

extern const char dummy_data[];
