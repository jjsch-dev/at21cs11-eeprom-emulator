#pragma once

#ifdef __cplusplus
extern "C"
{
#endif

void LED_Blink(void);

#ifdef __cplusplus
}
#endif